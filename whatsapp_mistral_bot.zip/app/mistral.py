import requests
from app.firebase import fetch_month_responses
import os

def generate_monthly_report(phone):
    responses = fetch_month_responses(phone)
    joined = "\n".join([f"{i+1}. {r}" for i, r in enumerate(responses)])
    prompt = f"""
    Summarize the following user responses into a kind monthly self-reflection report:

    {joined}

    Keep it conversational and encouraging.
    """
    response = requests.post("https://api.fireworks.ai/inference/v1/chat/completions", json={
        "model": "accounts/fireworks/models/mistral-7b-instruct", 
        "messages": [
            {"role": "user", "content": prompt}
        ]
    }, headers={"Authorization": f"Bearer {os.getenv('FIREWORKS_API_KEY')}", "Content-Type": "application/json"})

    return response.json()['choices'][0]['message']['content']