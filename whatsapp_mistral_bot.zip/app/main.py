from flask import Flask, request
from app.firebase import store_response
from app.mistral import generate_monthly_report
from app.utils import send_whatsapp_message, get_next_question

app = Flask(__name__)

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    phone = data['entry'][0]['changes'][0]['value']['messages'][0]['from']
    msg = data['entry'][0]['changes'][0]['value']['messages'][0]['text']['body']

    store_response(phone, msg)
    next_q = get_next_question(phone)
    send_whatsapp_message(phone, next_q)

    return 'OK', 200

@app.route('/generate-report', methods=['POST'])
def generate_report():
    phone = request.args.get('phone')
    report = generate_monthly_report(phone)
    send_whatsapp_message(phone, report)
    return 'Report sent', 200