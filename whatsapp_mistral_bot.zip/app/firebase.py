import firebase_admin
from firebase_admin import credentials, firestore
import datetime

cred = credentials.Certificate('firebase-creds.json')
firebase_admin.initialize_app(cred)
db = firestore.client()

def store_response(phone, message):
    today = datetime.date.today().isoformat()
    db.collection('users').document(phone).collection('responses').add({
        'date': today,
        'message': message
    })

def fetch_month_responses(phone):
    responses_ref = db.collection('users').document(phone).collection('responses')
    docs = responses_ref.stream()
    return [doc.to_dict()['message'] for doc in docs]